import io
import os
import runpy
import sys
import traceback


def run(path, stdin_text):
    """Запускает файл как __main__ и возвращает весь вывод (stdout + stderr)."""
    out = io.StringIO()
    old = (sys.stdout, sys.stderr, sys.stdin)
    folder = os.path.dirname(path)
    old_cwd = os.getcwd()

    sys.stdout = sys.stderr = out
    sys.stdin = io.StringIO(stdin_text or "")
    os.chdir(folder)
    sys.path.insert(0, folder)
    try:
        runpy.run_path(path, run_name="__main__")
    except SystemExit:
        pass
    except BaseException:
        traceback.print_exc()
    finally:
        sys.stdout, sys.stderr, sys.stdin = old
        os.chdir(old_cwd)
        if folder in sys.path:
            sys.path.remove(folder)
        # сбрасываем модули проекта, чтобы правки подхватывались при следующем запуске
        for name, mod in list(sys.modules.items()):
            f = getattr(mod, "__file__", None)
            if f and f.startswith(folder):
                sys.modules.pop(name, None)
    return out.getvalue()
