package com.pyide

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.text.*
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.OffsetMapping
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.input.TransformedText
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.chaquo.python.Python
import com.chaquo.python.android.AndroidPlatform
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

// ---------- Подсветка синтаксиса Python ----------

private val KEYWORDS = setOf(
    "False", "None", "True", "and", "as", "assert", "async", "await", "break", "class",
    "continue", "def", "del", "elif", "else", "except", "finally", "for", "from", "global",
    "if", "import", "in", "is", "lambda", "nonlocal", "not", "or", "pass", "raise", "return",
    "try", "while", "with", "yield", "self", "print"
)

private val TOKEN = Regex(
    """(#[^\n]*)|("{3}[\s\S]*?"{3}|'{3}[\s\S]*?'{3}|"(?:\\.|[^"\\\n])*"|'(?:\\.|[^'\\\n])*')|(\b\d+(?:\.\d+)?\b)|(\b[A-Za-z_]\w*\b)"""
)

private fun highlight(text: String): AnnotatedString = buildAnnotatedString {
    append(text)
    for (m in TOKEN.findAll(text)) {
        val color = when {
            m.groups[1] != null -> Color(0xFF7F848E)           // комментарий
            m.groups[2] != null -> Color(0xFF98C379)           // строка
            m.groups[3] != null -> Color(0xFFD19A66)           // число
            m.groupValues[4] in KEYWORDS -> Color(0xFFC678DD)  // ключевое слово
            else -> null
        }
        if (color != null) addStyle(SpanStyle(color = color), m.range.first, m.range.last + 1)
    }
}

private val PyTransform = VisualTransformation {
    TransformedText(highlight(it.text), OffsetMapping.Identity)
}

// ---------- Редактирование: автоотступ и вставка ----------

private fun autoIndent(old: TextFieldValue, new: TextFieldValue): TextFieldValue {
    if (new.text.length == old.text.length + 1 && new.selection.collapsed) {
        val pos = new.selection.start
        if (pos > 0 && new.text[pos - 1] == '\n') {
            val prevStart = new.text.lastIndexOf('\n', pos - 2) + 1
            val prev = new.text.substring(prevStart, pos - 1)
            var indent = prev.takeWhile { it == ' ' }
            if (prev.trimEnd().endsWith(":")) indent += "    "
            val t = new.text.substring(0, pos) + indent + new.text.substring(pos)
            return new.copy(text = t, selection = TextRange(pos + indent.length))
        }
    }
    return new
}

private fun insertAt(v: TextFieldValue, s: String, back: Int = 0): TextFieldValue {
    val a = v.selection.min
    val b = v.selection.max
    return v.copy(
        text = v.text.replaceRange(a, b, s),
        selection = TextRange(a + s.length - back)
    )
}

// ---------- Состояние IDE ----------

class Ide(val root: File) {
    val tabs = mutableStateListOf<File>()
    val texts = mutableStateMapOf<String, TextFieldValue>()
    var active by mutableIntStateOf(0)
    var files by mutableStateOf(listOf<File>())
    var console by mutableStateOf("")
    var running by mutableStateOf(false)
    var stdin by mutableStateOf("")

    fun refresh() {
        files = root.walkTopDown().filter { it.isFile }.sortedBy { it.path }.toList()
    }

    fun open(f: File) {
        if (tabs.none { it.path == f.path }) {
            tabs.add(f)
            texts[f.path] = TextFieldValue(f.readText())
        }
        active = tabs.indexOfFirst { it.path == f.path }
    }

    fun close(i: Int) {
        texts.remove(tabs[i].path)
        tabs.removeAt(i)
        active = active.coerceIn(0, maxOf(0, tabs.size - 1))
    }

    fun save(f: File) {
        texts[f.path]?.let { f.writeText(it.text) }
    }

    fun create(name: String) {
        val clean = name.trim()
        if (clean.isEmpty()) return
        val f = File(root, clean)
        // защита от выхода за пределы папки проекта
        if (!f.canonicalPath.startsWith(root.canonicalPath + File.separator)) return
        f.parentFile?.mkdirs()
        if (!f.exists()) f.writeText("")
        refresh()
        open(f)
    }

    fun delete(f: File) {
        val i = tabs.indexOfFirst { it.path == f.path }
        if (i >= 0) close(i)
        f.delete()
        refresh()
    }

    suspend fun runCode() {
        val f = tabs.getOrNull(active) ?: return
        tabs.forEach { save(it) }
        running = true
        console = "Запуск ${f.name}...\n"
        val result = withContext(Dispatchers.IO) {
            try {
                Python.getInstance().getModule("runner")
                    .callAttr("run", f.absolutePath, stdin).toString()
            } catch (e: Exception) {
                e.toString()
            }
        }
        console = result.ifEmpty { "(нет вывода)" }
        running = false
    }
}

// ---------- Activity ----------

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (!Python.isStarted()) Python.start(AndroidPlatform(this))

        val root = File(filesDir, "project").apply { mkdirs() }
        if (root.listFiles().isNullOrEmpty()) {
            File(root, "main.py").writeText("name = input(\"Как тебя зовут? \")\nprint(\"Привет,\", name)\n")
        }
        val ide = Ide(root)
        ide.refresh()
        ide.files.firstOrNull { it.name == "main.py" }?.let { ide.open(it) }
            ?: ide.files.firstOrNull()?.let { ide.open(it) }

        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) { IdeScreen(ide) }
        }
    }
}

// ---------- UI ----------

private val Mono = FontFamily.Monospace
private val EditorBg = Color(0xFF1E1E1E)

private data class QuickKey(val label: String, val text: String, val back: Int = 0)

private val QUICK_KEYS = listOf(
    QuickKey("Tab", "    "),
    QuickKey("()", "()", 1),
    QuickKey("[]", "[]", 1),
    QuickKey("{}", "{}", 1),
    QuickKey("\"\"", "\"\"", 1),
    QuickKey("''", "''", 1),
    QuickKey(":", ":"),
    QuickKey("=", "="),
    QuickKey("#", "#"),
    QuickKey("_", "_"),
    QuickKey(".", "."),
    QuickKey(",", ","),
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun IdeScreen(ide: Ide) {
    val drawer = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    var showNew by remember { mutableStateOf(false) }
    var newName by remember { mutableStateOf("") }

    ModalNavigationDrawer(
        drawerState = drawer,
        drawerContent = {
            ModalDrawerSheet {
                Text("Файлы проекта", modifier = Modifier.padding(16.dp), fontSize = 18.sp)
                Button(
                    onClick = { newName = ""; showNew = true },
                    modifier = Modifier.padding(horizontal = 16.dp)
                ) { Text("+ Новый файл") }
                LazyColumn(Modifier.padding(top = 8.dp)) {
                    items(ide.files) { f ->
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .clickable { ide.open(f); scope.launch { drawer.close() } }
                                .padding(start = 16.dp, end = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(f.relativeTo(ide.root).path, Modifier.weight(1f))
                            IconButton(onClick = { ide.delete(f) }) {
                                Icon(Icons.Default.Delete, "Удалить")
                            }
                        }
                    }
                }
            }
        }
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text("PyIDE") },
                    navigationIcon = {
                        IconButton(onClick = { scope.launch { drawer.open() } }) {
                            Icon(Icons.Default.Menu, "Файлы")
                        }
                    },
                    actions = {
                        IconButton(
                            enabled = !ide.running && ide.tabs.isNotEmpty(),
                            onClick = { scope.launch { ide.runCode() } }
                        ) {
                            Icon(Icons.Default.PlayArrow, "Запустить", tint = Color(0xFF4CAF50))
                        }
                    }
                )
            }
        ) { pad ->
            Column(Modifier.padding(pad).fillMaxSize()) {

                // --- вкладки ---
                if (ide.tabs.isNotEmpty()) {
                    ScrollableTabRow(selectedTabIndex = ide.active, edgePadding = 0.dp) {
                        ide.tabs.forEachIndexed { i, f ->
                            Tab(selected = i == ide.active, onClick = { ide.active = i }) {
                                Row(
                                    Modifier.padding(start = 12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(f.name, maxLines = 1)
                                    IconButton(onClick = { ide.close(i) }, Modifier.size(32.dp)) {
                                        Icon(Icons.Default.Close, "Закрыть", Modifier.size(16.dp))
                                    }
                                }
                            }
                        }
                    }
                }

                // --- редактор ---
                val f = ide.tabs.getOrNull(ide.active)
                if (f != null) {
                    key(f.path) {
                        val v = ide.texts[f.path] ?: TextFieldValue("")
                        val lines = v.text.count { it == '\n' } + 1
                        val style = TextStyle(
                            fontFamily = Mono, fontSize = 14.sp, lineHeight = 20.sp,
                            color = Color(0xFFE0E0E0)
                        )
                        Row(
                            Modifier
                                .weight(1f)
                                .fillMaxWidth()
                                .background(EditorBg)
                                .verticalScroll(rememberScrollState())
                                .padding(vertical = 4.dp)
                        ) {
                            Text(
                                (1..lines).joinToString("\n"),
                                style = style.copy(color = Color(0xFF6B7078), textAlign = TextAlign.End),
                                modifier = Modifier.width(44.dp).padding(end = 8.dp)
                            )
                            BasicTextField(
                                value = v,
                                onValueChange = { n ->
                                    ide.texts[f.path] = autoIndent(v, n)
                                    ide.save(f)
                                },
                                textStyle = style,
                                softWrap = false,
                                cursorBrush = SolidColor(Color.White),
                                visualTransformation = PyTransform,
                                modifier = Modifier
                                    .weight(1f)
                                    .horizontalScroll(rememberScrollState())
                                    .defaultMinSize(minHeight = 200.dp)
                                    .onPreviewKeyEvent { e ->
                                        if (e.type == KeyEventType.KeyDown && e.key == Key.Tab) {
                                            val cur = ide.texts[f.path] ?: return@onPreviewKeyEvent false
                                            ide.texts[f.path] = insertAt(cur, "    ")
                                            ide.save(f)
                                            true
                                        } else false
                                    }
                            )
                        }

                        // --- панель быстрых клавиш (Tab и скобки) ---
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .background(Color(0xFF2B2B2B))
                                .horizontalScroll(rememberScrollState())
                        ) {
                            QUICK_KEYS.forEach { k ->
                                TextButton(onClick = {
                                    val cur = ide.texts[f.path] ?: return@TextButton
                                    ide.texts[f.path] = insertAt(cur, k.text, k.back)
                                    ide.save(f)
                                }) { Text(k.label, fontFamily = Mono) }
                            }
                        }
                    }
                } else {
                    Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                        Text("Открой файл через меню слева")
                    }
                }

                // --- ввод и консоль ---
                OutlinedTextField(
                    value = ide.stdin,
                    onValueChange = { ide.stdin = it },
                    label = { Text("Ввод для input() (по строке на вызов)") },
                    textStyle = TextStyle(fontFamily = Mono, fontSize = 13.sp),
                    maxLines = 2,
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp)
                )
                Text(
                    ide.console,
                    style = TextStyle(fontFamily = Mono, fontSize = 13.sp, color = Color(0xFFCFCFCF)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(150.dp)
                        .background(Color(0xFF111111))
                        .verticalScroll(rememberScrollState())
                        .padding(8.dp)
                )
            }
        }
    }

    if (showNew) {
        AlertDialog(
            onDismissRequest = { showNew = false },
            title = { Text("Новый файл") },
            text = {
                OutlinedTextField(
                    value = newName,
                    onValueChange = { newName = it },
                    placeholder = { Text("script.py") },
                    singleLine = true
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    ide.create(newName)
                    showNew = false
                    scope.launch { drawer.close() }
                }) { Text("Создать") }
            },
            dismissButton = { TextButton(onClick = { showNew = false }) { Text("Отмена") } }
        )
    }
}
